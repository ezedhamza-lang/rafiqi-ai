﻿import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { subjectLabel } from './analyticsService.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * تحويل مسار صورة منهجية (/curriculum/...) إلى data-URI مضمّن في الـHTML
 * حتى يراها محرك Chromium في PDF المذكرة دون اعتماد على رابط خارجي.
 */
export async function inlineImageForPdf(src) {
  const m = typeof src === 'string' && src.match(/^\/(curriculum|story-covers)\/(.+)$/);
  if (!m) return null;
  const rel = path.join(m[1] === 'curriculum' ? '' : m[1], m[2]);
  const roots = [
    path.join(__dirname, '../../curriculum/img'),
    path.join(__dirname, '../../uploads/curriculum')
  ];
  for (const root of roots) {
    for (const cand of [
      path.join(root, rel.replace(/\.(png|jpe?g)$/i, '.webp')),
      path.join(root, rel)
    ]) {
      try {
        if (!fs.existsSync(cand)) continue;
        const buf = fs.readFileSync(cand);
        if (!buf.length) continue;
        const mime = cand.endsWith('.webp') ? 'image/webp' : (/\.(jpe?g)$/i.test(cand) ? 'image/jpeg' : 'image/png');
        return `data:${mime};base64,${buf.toString('base64')}`;
      } catch { /* تجاهل */ }
    }
  }
  return null;
}

// ===== قوالب PDF الرسمية (تُرسم عبر محرك المتصفح — انظر browserPdf.js) =====
// كل المستندات الديناميكية تُهرَّب بـesc() ضد الحقن، والنص غير قابل للتحديد
// (user-select:none)، مع علامة مائية ثابتة واسم المنشئ في تذييل كل صفحة.

export const AUTHOR_CREDIT = 'الأستاذ والمهندس حمزة بن عمر عزالدين';

export function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[c]);
}

const money = (v) => `${Number(v ?? 0).toFixed(3)} د.ت`;

function baseHtml(title, body) {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"/>
<title>${esc(title)}</title>
<style>
  @page { size: A4; }
  * { box-sizing: border-box; }
  html, body {
    font-family: "Noto Naskh Arabic", "Amiri", "Segoe UI", Tahoma, Arial, sans-serif;
    color: #1f2937; margin: 0; line-height: 1.7; font-size: 12px;
    -webkit-user-select: none; -moz-user-select: none; user-select: none;
    -webkit-touch-callout: none; overflow-x: hidden;
  }
  .banner {
    background: linear-gradient(135deg, #0b2a52, #123a6b 55%, #0FA6E8);
    color: #fff; padding: 14px 20px; margin: -14mm -12mm 12px; border-radius: 0;
  }
  .banner h1 { margin: 0; font-size: 18px; }
  .banner p { margin: 2px 0 0; font-size: 11.5px; opacity: .92; }
  h2 { color: #0b6ca8; font-size: 15px; margin: 16px 0 6px; border-bottom: 2px solid #cfe8f7; padding-bottom: 3px; }
  table { width: 100%; border-collapse: collapse; margin: 6px 0 10px; }
  th, td { border: 1px solid #dbe7f0; padding: 5px 8px; text-align: right; font-size: 11.5px; }
  th { background: #eef6fb; color: #0b4a75; }
  .kv td:first-child { color: #64748b; width: 38%; }
  .total { font-weight: 800; color: #c2410c; font-size: 14px; }
  .note { font-size: 10.5px; color: #64748b; text-align: center; margin-top: 14px; }
  .page { padding: 0 4px; }
  .wm {
    position: fixed; top: 28%; left: 6%; right: 6%; width: 88%; text-align: center; z-index: 0;
    transform: rotate(-24deg); opacity: .11; font-size: 17px; font-weight: 800;
    color: #0b2a52; line-height: 2.1; pointer-events: none; overflow: hidden;
  }
  .credit {
    position: fixed; bottom: 0; left: 0; right: 0; text-align: center;
    font-size: 9.5px; color: #94a3b8; padding: 4px 0 0; border-top: 1px solid #e2e8f0;
  }
  .doc { position: relative; z-index: 1; }
</style>
</head>
<body>
<div class="wm">منصة رفيقي — وثيقة رسمية<br/>${esc(AUTHOR_CREDIT)}<br/>منصة رفيقي — وثيقة رسمية</div>
<div class="doc">
<div class="banner">
  <h1>بوابة رفيقي للحياة المدرسية</h1>
  <p>${esc(title)}</p>
</div>
${body}
</div>
<div class="credit">© ${esc(AUTHOR_CREDIT)} — جميع الحقوق محفوظة · منصة رفيقي ${new Date().getFullYear()} · هذه الوثيقة غير قابلة للنسخ</div>
</body>
</html>`;
}

// ===== الفاتورة =====
export function invoiceHtml(invoice) {
  const sub = invoice.subscription || {};
  const holder = sub.user || {};
  const roleLabels = { STUDENT: 'تلميذ', PARENT: 'ولي', TEACHER: 'أستاذ', SCHOOL_DIRECTOR: 'مدير مدرسة', ADMIN: 'مدير عام', SUPER_ADMIN: 'نظامي' };
  const holderName = `${holder.firstName || ''} ${holder.lastName || ''}`.trim() || '—';
  const rows = [
    ['رقم الفاتورة', invoice.invoiceNumber || '—'],
    ['تاريخ الإصدار', new Date(invoice.issuedAt).toLocaleDateString('ar-TN')],
    ['رقم العملية', `#${invoice.paymentId ?? '—'}`],
    ['الحالة', invoice.status === 'PAID' ? 'مُسدَّدة' : invoice.status]
  ];
  const body = `
<div class="page">
  <h2>فاتورة اشتراك رقمي</h2>
  <table class="kv"><tbody>${rows.map(([k, v]) => `<tr><td>${esc(k)}</td><td><b>${esc(v)}</b></td></tr>`).join('')}</tbody></table>
  <h2>المستفيد</h2>
  <p>${esc(holderName)} — ${esc(roleLabels[holder.role] || holder.role || '')} ${esc(holder.email || '')}</p>
  <h2>تفاصيل الاشتراك</h2>
  <table><thead><tr><th>الخطة</th><th>السنة الدراسية</th><th>الفترة</th><th>المبلغ</th></tr></thead>
  <tbody><tr><td>${esc(sub.plan || '—')}</td><td>${esc(sub.schoolYear || '—')}</td>
  <td>${sub.startDate ? `${new Date(sub.startDate).toLocaleDateString('fr-TN')} ← ${new Date(sub.endDate).toLocaleDateString('fr-TN')}` : '—'}</td>
  <td>${esc(money(invoice.amount))}</td></tr></tbody></table>
  <h2>التفصيل المالي</h2>
  <table class="kv"><tbody>
    <tr><td>المبلغ الأصلي</td><td>${esc(money(invoice.amount))}</td></tr>
    ${Number(invoice.discountAmount) > 0 ? `<tr><td>التخفيض${invoice.discountCode ? ` (${esc(invoice.discountCode)})` : ''}</td><td>-${esc(money(invoice.discountAmount))}</td></tr>` : ''}
    ${Number(invoice.taxAmount) > 0 ? `<tr><td>الضريبة</td><td>${esc(money(invoice.taxAmount))}</td></tr>` : ''}
    <tr><td>المجموع</td><td class="total">${esc(money(invoice.total))}</td></tr>
  </tbody></table>
  <p class="note">شكرا لثقتك بمنصة رفيقي. هذه الفاتورة صادرة إلكترونيا ولها نفس قيمة الأصل الورقي.</p>
</div>`;
  return baseHtml('فاتورة اشتراك', body);
}

// ===== كشف نتائج القسم =====
export function gradesHtml({ klass, rows, assignments }) {
  const mainRows = (rows || []).map((r) => `<tr><td>${esc(`${r.firstName} ${r.lastName}`)}</td><td>${esc(`${r.completionRate}%`)}</td><td>${esc(`${r.avgPercent}%`)}</td></tr>`).join('');
  const assignRows = (assignments || []).map((a) => `<tr><td>${esc(a.title)}</td><td>${esc(subjectLabel(a.subject))}</td><td>${esc(`${a.avgPercent}%`)}</td></tr>`).join('');
  const body = `
<div class="page">
  <h2>${esc(klass ? `${klass.name} — كشف النتائج` : 'كشف النتائج')}</h2>
  ${klass?.level ? `<p>المستوى: <b>${esc(klass.level)}</b></p>` : ''}
  <table><thead><tr><th>التلميذ</th><th>الإنجاز</th><th>المتوسط</th></tr></thead><tbody>${mainRows || '<tr><td colspan=3>لا توجد بيانات</td></tr>'}</tbody></table>
  ${(assignments || []).length ? `
  <h2>متوسطات التكليفات</h2>
  <table><thead><tr><th>التكليف</th><th>المادة</th><th>متوسط القسم</th></tr></thead><tbody>${assignRows}</tbody></table>` : ''}
</div>`;
  return baseHtml('كشف نتائج القسم', body);
}

// ===== التقرير المالي =====
export function financialReportHtml(report) {
  const s = report.summary || {};
  const sumRow = (k, v) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`;
  const months = (report.revenueByMonth || []).length
    ? report.revenueByMonth.map((r) => sumRow(r.month, money(r.amount))).join('')
    : sumRow('لا توجد بيانات', '');
  const pays = (report.payments || []).slice(0, 15).map((p) => `
    <tr><td>${esc(new Date(p.paidAt).toLocaleDateString('ar-TN'))}</td>
    <td>${esc(`${p.subscription?.user?.firstName || ''} ${p.subscription?.user?.lastName || ''}`)}</td>
    <td>${esc(p.subscription?.plan || '—')}</td><td>${esc(money(p.amount))}</td></tr>`).join('');
  const body = `
<div class="page">
  <h2>التقرير المالي</h2>
  <p>الفترة: <b>${esc(report.period?.label || '')}</b> — تاريخ التوليد: ${esc(new Date(report.generatedAt).toLocaleString('ar-TN'))}</p>
  <h2>ملخص مالي</h2>
  <table class="kv"><tbody>
    ${sumRow('الإيراد الإجمالي', money(s.totalRevenue))}
    ${sumRow('التخفيضات الممنوحة', `-${money(s.totalDiscounts)}`)}
    ${sumRow('الضرائب المحصّلة', money(s.totalTax))}
    ${sumRow('الإرجاعات', `-${money(s.totalRefunds)}`)}
    ${sumRow('صافي الإيراد', money(s.netRevenue))}
    ${sumRow('عدد العمليات', String(s.paymentCount ?? 0))}
    ${sumRow('عدد الفواتير', String(s.invoiceCount ?? 0))}
    ${sumRow('عدد الإرجاعات', String(s.refundCount ?? 0))}
  </tbody></table>
  <h2>الإيراد الشهري (آخر 12 شهرًا)</h2>
  <table class="kv"><tbody>${months}</tbody></table>
  <h2>أحدث عمليات الدفع</h2>
  <table><thead><tr><th>التاريخ</th><th>المستفيد</th><th>الخطة</th><th>المبلغ</th></tr></thead>
  <tbody>${pays || '<tr><td colspan=4>لا توجد عمليات</td></tr>'}</tbody></table>
  <p class="note">هذا التقرير صادر إلكترونيا ويصلح للمراجعة الداخلية.</p>
</div>`;
  return baseHtml('تقرير مالي للإدارة', body);
}

// ===== تقرير تقدم تلميذ (للأولياء) =====
export function childReportHtml({ student, report }) {
  const { summary = {}, strengths = [], weaknesses = [], trend = [] } = report || {};
  const li = (items) => (items.length ? items.map((x) => `<li>${esc(`${x.label}: ${x.avgPercent}%`)}</li>`).join('') : '<li>— لا توجد بعد</li>');
  const recent = (trend || []).slice(-12).map((t) => `<tr><td>${esc(t.title)}</td><td>${esc(t.subjectLabel)}</td><td>${esc(`${t.percent}%`)}</td></tr>`).join('');
  const body = `
<div class="page">
  <h2>تقرير تقدم التلميذ — ${esc(`${student.account?.firstName || ''} ${student.account?.lastName || ''}`)}</h2>
  <p>القسم: <b>${esc(student.class?.name || '—')}</b> — السنة الدراسية: <b>${esc(student.schoolYear || '—')}</b></p>
  <p>الدقة العامة: <b>${esc(`${summary.avgPercent ?? 0}%`)}</b> — الإنجاز: <b>${esc(`${summary.completionRate ?? 0}%`)}</b> — التقييمات المنجزة: <b>${esc(`${summary.gradedCount ?? 0} من ${summary.assignmentsTotal ?? 0}`)}</b></p>
  <h2>نقاط القوة</h2><ul>${li(strengths)}</ul>
  <h2>نقاط الضعف (تحتاج مرافقة)</h2><ul>${li(weaknesses)}</ul>
  <h2>آخر النتائج</h2>
  <table><thead><tr><th>التقييم</th><th>المادة</th><th>النتيجة</th></tr></thead>
  <tbody>${recent || '<tr><td colspan=3>— لا توجد نتائج بعد</td></tr>'}</tbody></table>
  <p class="note">رفيقي — الحياة المدرسية</p>
</div>`;
  return baseHtml('تقرير تقدم التلميذ', body);
}

// ===== مذكرة الأستاذ (درس/حصة) =====
export async function memoHtml(memo) {
  let c = memo.content;
  if (typeof c === 'string') { try { c = JSON.parse(c); } catch { c = {}; } }
  c = c || {};
  if (c.spec && c.spec.specVersion === 2) return await memoSpecHtml(memo, c.spec);
  const secs = [];
  if (c.methodologyTitle) {
    secs.push('<h2>البروفايل المنهجي المعتمد</h2><p><b>' + esc(c.methodologyTitle) + '</b>' + (c.principle ? '<br/>' + esc(c.principle) : '') + '</p>');
  }
  if (c.header && (c.header.columns || []).length) {
    const vals = c.header.values || {};
    secs.push('<h2>بيانات الحصة</h2><table class="kv"><tbody>' + c.header.columns.map((k) => '<tr><td>' + esc(k) + '</td><td><b>' + esc(vals[k] || '—') + '</b></td></tr>').join('') + '</tbody></table>');
  }
  // ملاحظة: المذكرات بلا صور حسب معيار المستخدم (قابلة للتعديل يدويًا في Word)
  if ((c.warmup || []).length) {
    secs.push('<h2>التمهيد</h2><ul>' + c.warmup.map((w) => '<li>' + esc(w) + '</li>').join('') + '</ul>');
  }
  if (c.table && (c.table.columns || []).length) {
    const cols = (c.table.columns || []).map((x) => '<th>' + esc(x) + '</th>').join('');
    const rows = (c.table.rows || []).map((r) => '<tr>' + c.table.columns.map((col) => '<td>' + esc(r[col] || '—') + '</td>').join('') + '</tr>').join('');
    secs.push('<h2>جدول سير الحصة</h2><table><thead><tr>' + cols + '</tr></thead><tbody>' + rows + '</tbody></table>');
  }
  if ((c.phases || []).length) {
    secs.push('<h2>مراحل الحصة</h2>' + c.phases.map((p, i) => {
      let s = '<div class="phase"><p><b>' + (i + 1) + '. ' + esc(p.name || '') + '</b></p>';
      if (p.goal) s += '<p>' + esc(p.goal) + '</p>';
      if ((p.activities || []).length) s += '<ul>' + p.activities.map((a) => '<li>' + esc(a) + '</li>').join('') + '</ul>';
      if ((p.notes || []).length) s += '<ul>' + p.notes.map((n) => '<li>' + esc(n) + '</li>').join('') + '</ul>';
      return s + '</div>';
    }).join(''));
  }
  if ((c.keywords || []).length) {
    secs.push('<h2>الكلمات المفتاحية</h2><p>' + c.keywords.map((k) => esc(k)).join(' ، ') + '</p>');
  }
  if ((c.definitions || []).length) {
    secs.push('<h2>المفاهيم</h2><ul>' + c.definitions.map((d) => '<li><b>' + esc(d) + '</b></li>').join('') + '</ul>');
  }
  if ((c.domainNotes || []).length) {
    secs.push('<h2>ملاحظات حسب المجال</h2>' + c.domainNotes.map((dn) => '<p><b>' + esc(dn.domain || '') + ':</b> ' + esc(dn.note || '') + '</p>').join(''));
  }
  if ((c.closing || []).length) {
    secs.push('<h2>الختام</h2><ul>' + c.closing.map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul>');
  }
  const body = '<div class="page">' + (secs.join('') || '<p>لا تحتوي هذه المذكرة على محتوى.</p>') + '</div>';
  return baseHtml('مذكرة حصة: ' + (memo.lessonTitle || ''), body);
}

// ===== دفتر الأعداد =====
export function gradesBookHtml(data) {
  const cols = ['التلميذ', ...data.subjects.map((s) => `${s.label}<br/><span class="coef">معامل ${s.coefficient}</span>`), `معدل ${data.periodLabel}`, 'الرتبة', 'التجدير'];
  const rows = data.rows.map((r) => '<tr><td class="nm">' + esc(`${r.firstName} ${r.lastName}`) + '</td>'
    + data.subjects.map((s) => '<td>' + (r.marks[s.code] == null ? '—' : Number(r.marks[s.code]).toFixed(2)) + '</td>').join('')
    + '<td class="mean">' + (r.mean == null ? '—' : Number(r.mean).toFixed(2)) + '</td>'
    + '<td>' + (r.rank == null ? '—' : `${r.rank}/${data.effectifs}`) + '</td>'
    + '<td>' + esc(r.mention || '—') + '</td></tr>').join('');
  const body = `
<div class="page">
  <h2>دفتر الأعداد — ${esc(data.class.name)} (${esc(data.class.level)})</h2>
  <p>السنة الدراسية: <b>${esc(data.class.schoolYear || '')}</b> — الفترة: <b>${esc(data.periodLabel)}</b> — عدد التلاميذ: ${data.studentsCount}</p>
  <table class="gb"><thead><tr>${cols.map((c) => '<th>' + c + '</th>').join('')}</tr></thead><tbody>${rows || '<tr><td colspan=9>لا توجد بيانات</td></tr>'}</tbody></table>
  <p class="note">المعدل = Σ(العدد × المعامل) ÷ Σ المعاملات، والمعدل السنوي = (الأول + الثاني + 2×الثالث) ÷ 4.</p>
</div>
<style>.gb th,.gb td{font-size:9.5px;padding:3px 4px;text-align:center}.gb .nm{text-align:right;white-space:nowrap}.gb .coef{font-weight:400;font-size:8.5px}.gb .mean{font-weight:800}</style>`;
  return baseHtml('دفتر الأعداد', body);
}

// ===== شهادة / بطاقة الأعداد =====
export function certificateHtml(cert) {
  const triCols = ['1', '2', '3'].map((k) => '<td>' + (cert.triMeans && cert.triMeans[k] != null ? Number(cert.triMeans[k]).toFixed(2) : '—') + '</td>').join('');
  const isAnnual = cert.period === 'annual';
  const body = `
<div class="page">
  <div class="cert-head">
    <div class="cert-rep">الجمهورية التونسية — وزارة التربية</div>
    <div class="cert-school">${esc(cert.class.schoolName || '')} — إدارة المدرسة</div>
    <h2>${isAnnual ? 'بطاقة المعدل السنوي' : 'بطاقة الأعداد — ' + esc(cert.periodLabel)}</h2>
    <div class="cert-who">
      <span>التلميذ(ة): <b>${esc(cert.student.firstName)} ${esc(cert.student.lastName)}</b></span>
      <span>القسم: <b>${esc(cert.class.name)}</b></span>
      <span>المستوى: <b>${esc(cert.class.level)}</b></span>
      <span>السنة الدراسية: <b>${esc(cert.class.schoolYear || '')}</b></span>
    </div>
  </div>
  <table class="cert">
    <thead><tr><th>المادة</th><th>المعامل</th><th>${isAnnual ? 'المعدل السنوي للمادة' : 'العدد على 20'}</th>${isAnnual ? '' : '<th>الجداء</th>'}</tr></thead>
    <tbody>
      ${cert.subjects.map((s) => '<tr><td class="nm">' + esc(s.label) + '</td><td>' + (s.coefficient || 1) + '</td><td>' + (s.mark == null ? '—' : Number(s.mark).toFixed(2)) + '</td>' + (isAnnual ? '' : '<td>' + (s.product == null ? '—' : Number(s.product).toFixed(2)) + '</td>') + '</tr>').join('')}
      <tr class="sum"><td>المجموع</td><td>${cert.sumCoefs}</td><td>${cert.sumProducts.toFixed(2)}</td><td></td></tr>
    </tbody>
  </table>
  <div class="cert-result">
    <div class="big">المعدل ${isAnnual ? 'السنوي' : 'الثلاثي'}: <b>${cert.mean == null ? '—' : Number(cert.mean).toFixed(2)}</b> / 20</div>
    <div>الرتبة: <b>${cert.rank == null ? '—' : cert.rank}</b> من ${cert.effectifs}</div>
    <div>التجدير: <b>${esc(cert.mention || '—')}</b></div>
    ${!isAnnual ? '<div>الثلاثيات: ' + triCols + '</div><div>المعدل السنوي الحالي: ' + (cert.annual == null ? '—' : Number(cert.annual).toFixed(2)) + '</div>' : ''}
    ${isAnnual && cert.decision ? '<div class="dec">القرار: <b>' + esc(cert.decision) + '</b></div>' : ''}
  </div>
  <div class="cert-signs">
    <div>توقيع الأستاذ(ة)<br/><br/>………………</div>
    <div>توقيع مدير(ة) المدرسة<br/><br/>………………</div>
  </div>
  <p class="note">وثيقة صادرة إلكترونيا من منصة «رفيقي» — المعدل محسوب وفق صيغة وزارة التربية: Σ(عدد×معامل)÷Σ المعاملات.</p>
</div>
<style>.cert-head{text-align:center;margin-bottom:8px}.cert-rep{font-weight:800}.cert-school{font-size:11px;color:#566}.cert h2{border:none;margin:6px 0}.cert-who{display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;font-size:11.5px;background:#f4f8fb;border:1px solid #d7e5f0;padding:6px 10px;border-radius:8px;margin-top:6px}table.cert{width:100%}table.cert td,table.cert th{font-size:11px;padding:4px 6px}table.cert .nm{text-align:right}table.cert .sum td{font-weight:800;background:#eef6fb}.cert-result{display:flex;flex-wrap:wrap;gap:14px;align-items:center;margin-top:12px;font-size:12px}.cert-result .big{font-size:14px}.cert-result .dec{width:100%;font-weight:700;color:#0b6ca8}.cert-signs{display:flex;justify-content:space-between;margin-top:26px;font-size:11px;text-align:center}</style>`;
  return baseHtml(cert.period === 'annual' ? 'بطاقة المعدل السنوي' : 'بطاقة الأعداد', body);
}

// ===== مذكرة بيداغوجية — قالب المواصفات الرسمية (v2) =====
// GLES match: 3 tables from the official Word template
//   Table 0: Banner — 1 row × 3 cols (التوقيت | العنوان | المستوى)
//   Table 1: Competency — 4 rows × 2 cols (empty | label)
//   Table 2: Activity — header + N rows × 4 cols (المراحل | نشاط المعلّم | نشاط المتعلّم | الوسائل)
async function memoSpecHtml(memo, s) {
  const lines = (t) => esc(String(t || '')).replace(/\n/g, '<br/>');

  // ── Table 0: Banner ──
  // Official docx: all templates use "المستوى" (not "الفترة")
  // Banner title: "مذكرة [المادة]" (e.g. "مذكرة رياضيات" / "مذكرة انتاج كتابي")
  const duration = esc((s.banner && s.banner.duration) || (s.mathTemplate ? 'التوقيت: 60 دق' : 'التوقيت : 30 دق'));
  const titleText = s.mathTemplate
    ? esc((s.banner && s.banner.title) || 'مذكرة رياضيات')
    : esc((s.banner && s.banner.title) || s.headerTitle || ('مذكرة ' + (s.subjectWord || '')));
  const levelText = s.mathTemplate
    ? esc((s.banner && s.banner.level) || '')
    : esc(s.period || '…');
  const levelLabel = 'المستوى'; // all official templates use المستوى
  const bannerTable =
    '<table class="mtpl"><tr>' +
    '<td class="tpl-hdr">' + duration + '</td>' +
    '<td class="tpl-hdr tpl-title">' + titleText + '</td>' +
    '<td class="tpl-hdr">' + levelLabel + ' : ' + levelText + '</td>' +
    '</tr></table>';

  // ── Table 1: Competency block ──
  const compDefs = s.mathTemplate
    ? [
        ['مكون الكفاية', s.competencies?.component],
        ['الهدف المميّز', s.competencies?.distinctiveObjective],
        ['المحتوى', s.content],
        ['هدف الحصة', (s.lessonObjectives || []).join('؛ ')]
      ]
    : [
        ['كفاية المجال', s.competencies?.domain],
        ['كفاية المادة', s.competencies?.subject],
        ['مكوّن الكفاية', s.competencies?.component],
        ['الهدف المميّز', s.competencies?.distinctiveObjective]
      ];
  // RTL docx: Cell 0 = right, Cell 1 = left. Official template: Cell 0 empty, Cell 1 = label.
  const compRows = [];
  for (const [label, val] of compDefs) {
    if (val) compRows.push('<tr><td></td><td class="tpl-lbl">' + esc(label) + '</td></tr>');
    else if (s.mathTemplate && label !== 'المحتوى') compRows.push('<tr><td></td><td class="tpl-lbl">' + esc(label) + '</td></tr>');
  }
  if (!s.mathTemplate) {
    for (let i = 0; i < (s.lessonObjectives || []).length; i++) {
      compRows.push('<tr><td></td><td class="tpl-lbl">هدف الحصّة ' + (i + 1) + '</td></tr>');
    }
  }
  if (s.content && !s.mathTemplate) compRows.push('<tr><td></td><td class="tpl-lbl tpl-content">المحتوى</td></tr>');
  const compTable = '<table class="mtpl mcomp">' + compRows.join('') + '</table>';

  // ── Activity rows ──
  const trs = [];
  for (const r of s.rows || []) {
    trs.push(
      '<tr>' +
      '<td class="stg">' + esc(r.stage) + '</td>' +
      '<td>' + lines(r.teacherActivity) + '</td>' +
      '<td>' + lines(r.learnerActivity) + '</td>' +
      '<td class="tls">' + esc((r.tools || []).join(' + ') || '—') + '</td>' +
      '</tr>'
    );
  }
  // Official docx: all templates use 4 columns (المراحل | نشاط المعلّم | نشاط المتعلّم | الوسائل)
  const actHeaders = '<th>المراحل</th><th>نشاط المعلّم</th><th>نشاط المتعلّم</th><th>الوسائل</th>';
  const actTable =
    '<table class="mtab"><thead><tr>' + actHeaders + '</tr></thead><tbody>' +
    trs.join('') + '</tbody></table>';

  // ── CSS ──
  const style = '<style>' +
    // Table 0-1 shared: official bordered look
    'table.mtpl{width:100%;border-collapse:collapse;margin:0 0 10px;table-layout:fixed}' +
    'table.mtpl td{border:1.5px solid #111;padding:7px 10px;font-size:13px;vertical-align:middle}' +
    // Banner row
    'table.mtpl .tpl-hdr{background:#f5edd6;text-align:center;font-weight:700;font-size:14px}' +
    'table.mtpl .tpl-title{font-size:17px;background:#e8dfc4}' +
    // Competency block: label column
    'table.mtpl .tpl-lbl{background:#e8f5e2;text-align:center;font-weight:700;width:22%;white-space:nowrap}' +
    'table.mtpl .tpl-content{background:#eef4fb}' +
    // Activity table
    'table.mtab{width:100%;border-collapse:collapse;font-size:13px;margin-top:2px}' +
    'table.mtab th{border:2px solid #111;padding:7px 8px;font-size:14px;font-weight:700;color:#1d2430;text-align:center}' +
    'table.mtab thead th:nth-child(1){background:#d9b45b}' +
    'table.mtab thead th:nth-child(2){background:#a8c8e8}' +
    'table.mtab thead th:nth-child(3){background:#a9dcb9}' +
    'table.mtab thead th:nth-child(4){background:#d3bce8}' +
    'table.mtab thead th:nth-child(5){background:#f0c9b0}' +
    'table.mtab td{border:2px solid #111;padding:8px 9px;vertical-align:top;line-height:1.85}' +
    'table.mtab td.stg{font-weight:800;text-align:center;white-space:normal;width:11%;direction:rtl;font-size:14px}' +
    'table.mtab tbody tr:nth-child(6n+1) td.stg{background:#f3e2b6}' +
    'table.mtab tbody tr:nth-child(6n+2) td.stg{background:#c9def3}' +
    'table.mtab tbody tr:nth-child(6n+3) td.stg{background:#cdeed4}' +
    'table.mtab tbody tr:nth-child(6n+4) td.stg{background:#e6d4f5}' +
    'table.mtab tbody tr:nth-child(6n+5) td.stg{background:#f8d4c8}' +
    'table.mtab tbody tr:nth-child(6n+6) td.stg{background:#d4ecec}' +
    'table.mtab td.skl{width:12%;text-align:center;color:#274d27;font-weight:700}' +
    'table.mtab td.tls{width:12%;text-align:center;color:#333;font-weight:600}' +
    // Bottom section
    '.mend{border:2px solid #b9c8ae;border-radius:8px;padding:12px 16px;margin-top:14px;background:#fbf9f4;font-size:13.5px}' +
    '.mfill{border-bottom:2.5px dotted #555;height:28px;margin:6px 0 10px}' +
    '.mtip{font-size:11px;color:#666;margin-top:4px}' +
    '@media print { thead { display: table-header-group; } table.mtab tr { break-inside: avoid; } }' +
    '</style>';

  // ── Body ──
  const body = '<div class="page">' + style +
    bannerTable +
    compTable +
    actTable +
    (s.assessment ? '<div style="margin-top:8px;font-size:11px"><b>عناصر التقويم المطبَّقة:</b> ' + lines(s.assessment) + '</div>' : '') +
    '<div class="mend">' +
    '<b>' + esc(s.successRateLine || 'نسبة نجاح الدرس من خلال التمرين التطبيقي:') + '</b><div class="mfill"></div>' +
    '<b>' + esc(s.pedagogicalDecision || 'القرار البيداغوجي:') + '</b><div class="mfill"></div><div class="mfill"></div>' +
    (s.decisionHints ? '<div class="mtip">' + esc(s.decisionHints) + '</div>' : '') +
    '</div></div>';
  return baseHtml('مذكرة بيداغوجية: ' + (memo.lessonTitle || ''), body);
}

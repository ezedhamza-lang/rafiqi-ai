import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { getHomePath } from '../../roles.js';
import { useI18n } from '../../i18n/index.jsx';
const Licenses = lazy(() => import('./Licenses.jsx'));
const Subscriptions = lazy(() => import('./Subscriptions.jsx'));
const UsersAdmin = lazy(() => import('./UsersAdmin.jsx'));
const Schools = lazy(() => import('./Schools.jsx'));
import SpaceShell from '../../components/SpaceShell.jsx';

const TABS = [
  { to: '', end: true, icon: 'vpn_key', key: 'licenses', color: '#E8A317' },
  { to: 'subscriptions', icon: 'subscriptions', key: 'subscriptions', color: '#0ea5e9' },
  { to: 'users', icon: 'manage_accounts', key: 'users', color: '#10b981' },
  { to: 'schools', icon: 'school', key: 'schools', color: '#8b5cf6' }
];

export default function SuperAdminDashboard() {
  const { user } = useAuth();
  const { t } = useI18n();

  if (!user || user.role !== 'SUPER_ADMIN') {
    return <Navigate to={getHomePath(user)} replace />;
  }

  return (
    <div className="superadmin-space">
      <div className="space-head">
        <div>
          <h2>{t('superadmin.title')}</h2>
          <p className="sub">{t('superadmin.subtitle')}</p>
        </div>
      </div>

      <SpaceShell
        base="/superadmin"
        title={t('superadmin.title')}
        storageKey="rafiqi-super-sidebar"
        items={TABS.map((tb) => ({ ...tb, label: t(`superadmin.tabs.${tb.key}`) }))}
      >
        <Suspense fallback={null}>
        <Routes>
          <Route index element={<Licenses />} />
          <Route path="subscriptions" element={<Subscriptions />} />
          <Route path="users" element={<UsersAdmin />} />
          <Route path="schools" element={<Schools />} />
          <Route path="*" element={<Navigate to="." replace />} />
        </Routes>
      </Suspense>
      </SpaceShell>
    </div>
  );
}
